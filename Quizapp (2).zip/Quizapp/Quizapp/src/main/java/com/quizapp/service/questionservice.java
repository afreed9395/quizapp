package com.quizapp.service;
//in this service layer the request that you got from the controller is evaluated or processed.

import com.quizapp.dao.questiondao;
import com.quizapp.questionmodel.question;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service // since this is sevice layer to make spring understand what class is what layer we use annotations like service and contrller
public class questionservice {
    @Autowired
    static  //whenever we are declaring an object we are using this autowired annotation.
    questiondao questiond;
    public static ResponseEntity<List<question>> getAllquestions(){
         try{
             return new ResponseEntity<>(questiond.findAll(), HttpStatus.OK);  //this findall() function returns all the data in the table mapped into the declared variables
         }catch(Exception e){
             e.printStackTrace();
         }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
         //if some error occurs we are returning empty array.And the status here will be the bad request.

    }
    public ResponseEntity<List<question>> getAllQuestionbycategory(String Category){
        try {


            return new ResponseEntity<>(questiond.findByCategory(Category), HttpStatus.OK);
        }catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<String> addquestion(question qn) {
       try {
           questiond.save(qn);
           return new ResponseEntity<>("successully added", HttpStatus.CREATED);
       }catch(Exception e){
           e.printStackTrace();
       }
        return new ResponseEntity<>("Not added due to some error", HttpStatus.BAD_REQUEST);
    }

    public String deletebyId(int id) {
        questiond.deleteById(id);
        return "successfully deleted";
    }

    public String updateQuestion(question qn) {
        questiond.saveAndFlush(qn);
        return "successfully updated";
    }
}
