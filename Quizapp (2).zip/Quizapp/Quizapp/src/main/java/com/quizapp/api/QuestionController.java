package com.quizapp.api;

import com.quizapp.questionmodel.question;
import com.quizapp.service.questionservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//controller is responsible to communicate with user and it accepts the requests from the user
//and then the request goes to the service layer


@RestController
//THIS IS WHERE I WANT TO ACCEPT THE REQUEST SO WE ARE USING THIS RESTCONTROLLER ANNOTATION
@RequestMapping("question") //inside the brackets path is given to get the questions.
public class QuestionController {
    @Autowired  //this annotation is useful because in spring framework we need not to do always new key for creating object
    questionservice Questionservice;
    @GetMapping("allquestions")
    public ResponseEntity<List<question>> getallquestions(){  // here we need to return multiple objects i.e, a list of questions.
        //its a job of good programmer that along with the data that you send to the client you also need to send the
        // http status since it makes easy to understand for user that process was successful or not etc.
        //AS  a UI/Ux developer its ur duty to make user understand each action.For this we are using http status codes.
        return Questionservice.getAllquestions();
    }
        @GetMapping("Category/{Category}")
    public ResponseEntity<List<question>> getQuestionbyCategory(@PathVariable String Category){
        return Questionservice.getAllQuestionbycategory(Category);
    }

    //adding question to database
    //to add a question we can use postman(api) or any api
    @PostMapping("add")
    public ResponseEntity<String> addQuestion(question qn){
        return Questionservice.addquestion(qn);
    }
    @DeleteMapping("delete/{id}")
    public String deletequestionBYID(int id){
       return Questionservice.deletebyId(id);
    }
    @PutMapping
    public String updatequestion(question qn){
        return Questionservice.updateQuestion(qn);
    }
}
