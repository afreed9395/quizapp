package com.quizapp.dao;
//in order to do processing u may need some data which is stored in database so to access that data we have one more
//layer called "dao" (data access object) its just a interface btwn service layer and database.
import com.quizapp.questionmodel.question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface questiondao extends JpaRepository<question,Integer> {
                                                 //<CLASSNAME,PRIMARY KEY TYPE>
//here what we are doing is we are extending the jpa repository of our database which we have given access to connect with this
    //app in application.properties and all that data is mapped into the respective variables that we have declared in model class
    //
    public List<question> findByCategory(String Category);
    //here the jpa is smart enough to give you data because the coloumn category is present in our database
    //just understand that jpa takes the control over our table from database which we gonna connect to our app and
    //it is smart enough to process any request we pass.

    @Query(value="SELECT * FROM question q Where q.Category=:Category ORDER BY RANDOM() LIMIT:n",nativeQuery = true)
    public List<question> findrandomQuestionbyCategory(String Category , int n);
}
