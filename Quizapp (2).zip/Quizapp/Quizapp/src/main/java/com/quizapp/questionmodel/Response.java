package com.quizapp.questionmodel;

import jakarta.persistence.Entity;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Entity
@RequiredArgsConstructor  // this will provide the parametrised as well as the default constructor.
public class Response {
    private Integer id;
    private String answer;
}
