package com.quizapp.service;

import com.quizapp.dao.Quizdao;
import com.quizapp.dao.questiondao;
import com.quizapp.questionmodel.QuestionWrapper;
import com.quizapp.questionmodel.Quiz;
import com.quizapp.questionmodel.Response;
import com.quizapp.questionmodel.question;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
//here we will create quiz table in database and that is mapped by separate jparepository and the questions in quiz can be added
//by mapping so here we need to follow many to many mapping between two tables i.e; quiz table and question table.
//why many to many because if we follow one to one  then each quiz will have only one question
//if we follow one to many then the questions in quiz1 cannot be common in questions in quiz2;
public class Quizservice {
    @Autowired
    Quizdao quizdao;
    @Autowired
    questiondao quesdao;
    public ResponseEntity<String> createquiz(String Category,int n, String title){

      Quiz quiz =new Quiz();
      List<question> questions= quesdao.findrandomQuestionbyCategory(Category,n);
        quiz.setTitle(title);
        quiz.setQuestions(questions);
        quizdao.save(quiz);
        return new ResponseEntity<>("success",HttpStatus.CREATED);

    }



    public ResponseEntity<List<QuestionWrapper>> getquizquestions(int id) {
        Optional<Quiz> quiz =quizdao.findById(id); //here we are using this optional tag because we dont know that the quiz we are

        //searching for might present or not it can also be null ,so inorder to handle that we use Optional tag.

        //Second thing here is iam getting quiz by above operations ,so it means iam getting all questions type of object
        //which also contains the right answer ,so i need to convert this question objects to questionwrapper objects
        List<question> questionfromDB = quiz.get().getQuestions();
        //we can use these getter and setter functions effortlessly because of the inclusion of lombok dependency.


        //now we are using a loop and converting question objects one by one from quiz into questionwrapper.
        List<QuestionWrapper> questionsforUser = new ArrayList<>();

        //making questionwrapper using for loop
        for(question q: questionfromDB){
            QuestionWrapper qw = new QuestionWrapper(q.getId(),q.getQuestion_title(),q.getOption1(),q.getOption2(),q.getOption3(),q.getOption4());
            questionsforUser.add(qw);
        }
        return new ResponseEntity<>(questionsforUser,HttpStatus.OK);
    }

    public ResponseEntity<Integer> getscore(Integer id, List<Response> responses) {
        int score= 0;
       Optional<Quiz> quiz = quizdao.findById(id);
       List<question> questionsofQuiz = quiz.get().getQuestions();
       //since it is optional we need to use get() and then use getter function.
        for(Response response : responses){
            for(question q: questionsofQuiz){
                if(response.getAnswer().equals(q.getRight_answer()))
                    score++;
            }
        }
        return new ResponseEntity<>(score,HttpStatus.OK);
    }
}
