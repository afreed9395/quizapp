package com.quizapp.questionmodel;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.Data;
import org.springframework.data.annotation.Id;

//orm(object relational mapping) framework that we are using here is jpa
@Data  //this make sures that we need not to create separate getter and setters for each variable
   // this annotation comes from lombok dependency which will take care of it.

@Entity // this annotations make sure that we are mapping the data in the table with this class.
public class question {
    //class fields are your table coloumns

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String Category;
    private String difficulty_level;
    private String question_title;
    private String option1;
    private String option2;
    private String option3;
    private String option4;
    private String right_answer;

}
