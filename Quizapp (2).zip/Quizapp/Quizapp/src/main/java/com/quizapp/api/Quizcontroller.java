package com.quizapp.api;

import com.quizapp.questionmodel.QuestionWrapper;
import com.quizapp.questionmodel.Quiz;
import com.quizapp.questionmodel.Response;
import com.quizapp.service.Quizservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController("quiz")
public class Quizcontroller {
    @Autowired
    Quizservice quizservice;
    @PostMapping("create")
    public ResponseEntity<String> create(@RequestParam String Category,@RequestParam int n,@RequestParam String title){
        return quizservice.createquiz(Category,n,title);
    }
    @GetMapping("get/{id}")
    public ResponseEntity<List<QuestionWrapper>> getquiz(@PathVariable int id){
        return quizservice.getquizquestions(id);
    }
    //here why we returning the questionwrapper because this question wrapper contains only questions and respective options
    //and not the right answer.once see the wrapper class

    //Now we are calculating score for the quiz  submitted from the user.

    @PostMapping("submit/{id}")
    public ResponseEntity<Integer> submitans(@PathVariable Integer id,@RequestBody List<Response> responses){
               return quizservice.getscore(id,responses);
    }
}
