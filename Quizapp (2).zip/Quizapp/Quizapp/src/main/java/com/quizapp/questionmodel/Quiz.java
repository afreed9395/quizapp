package com.quizapp.questionmodel;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data //this means we need not to define getters and setters that will be taken care by lombok.
@Entity  //this means we are creating different table.

public class Quiz {
    @Id //this tells that next variable is primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) //this will generate the sequence of
    private Integer id;
    private String title;
    @ManyToMany
    private List<question> questions;

}
